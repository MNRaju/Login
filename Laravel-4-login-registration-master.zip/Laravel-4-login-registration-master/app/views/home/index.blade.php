@extends('master')

@section('content')

<h4>Hello</h4>



@stop