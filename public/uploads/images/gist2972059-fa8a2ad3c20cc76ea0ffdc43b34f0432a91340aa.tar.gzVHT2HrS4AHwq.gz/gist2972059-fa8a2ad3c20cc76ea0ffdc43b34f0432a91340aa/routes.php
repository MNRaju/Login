Route::get('edit', function() {
    // fetch our post, and it's associated categories
    $post = Post::with('cats')->where('id', '=', $id)->first();

    // fetch all of our categories
    $cats = Cat::all();

    // create our empty array
    $post_cats = array();

    // loop through each post category, and add the id to our array
    foreach ($post->cats as $cat) {
        $post_cats[] = $cat->id;
    }

    return View::make('edit'))->with('post', $post)
                              ->with('cats', $cat)
                              ->with('posts_cats', $posts_cats);
});