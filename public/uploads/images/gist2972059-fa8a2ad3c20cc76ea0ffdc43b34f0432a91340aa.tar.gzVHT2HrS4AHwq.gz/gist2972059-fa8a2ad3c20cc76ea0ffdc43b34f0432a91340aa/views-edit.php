<p>Categories</p>
<ul>
@foreach($cats as $cat)
    <li>{{ Form::checkbox('cats[]', $cat->id, in_array($cat->id, $post_cats)) }} {{ Form::label('cats_'.$cat->id, $cat->title) }}</li>
@endforeach
</ul>